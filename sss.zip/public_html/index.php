<?php
require_once __DIR__ . '/inc/config.php';
require_once __DIR__ . '/inc/auth.php';
$auth = new Auth();
if ($auth->isLoggedIn()) header('Location: dashboard.php');
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head><meta charset="UTF-8"><title><?= APP_NAME ?></title><link rel="stylesheet" href="assets/css/style.css"></head>
<body>
    <div class="hero"><div class="hero-content">
        <h1>🚀 <?= APP_NAME ?></h1>
        <p>جلسات RDP مع مزامنة المجلدات</p>
        <a href="github-login.php" class="btn-github">🔐 تسجيل الدخول عبر GitHub</a>
    </div></div>
</body>
</html>