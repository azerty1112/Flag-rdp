<?php
require_once __DIR__ . '/inc/config.php';
require_once __DIR__ . '/inc/auth.php';
require_once __DIR__ . '/inc/database.php';
$auth = new Auth();
if (!$auth->isLoggedIn()) header('Location: index.php');
$user = $auth->getUser();
$db = Database::getInstance();
$sessions = $db->getPDO()->prepare("SELECT * FROM sessions WHERE user_id = ? ORDER BY created_at DESC");
$sessions->execute([$user['id']]);
$sessions = $sessions->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html dir="rtl">
<head><title>لوحة التحكم</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body>
    <div class="container">
        <div class="header"><h1>مرحباً <?= htmlspecialchars($user['username']) ?></h1>
        <a href="folder_manager.php">📁 مجلداتي</a> <a href="logout.php">🚪 خروج</a></div>
        <h2>📋 جلساتي</h2>
        <div class="sessions-grid">
            <?php foreach ($sessions as $s): ?>
                <div class="session-card">
                    <div class="session-status <?= $s['status'] ?>"><?= $s['status'] ?></div>
                    <div>🆔 <?= substr($s['session_id'], 0, 16) ?></div>
                    <div>📅 <?= date('Y-m-d H:i', $s['created_at']) ?></div>
                    <?php if ($s['host']): ?>
                        <div>🌐 <code><?= htmlspecialchars($s['host']) ?></code></div>
                        <div>👤 <code><?= htmlspecialchars($s['username']) ?></code></div>
                        <div>🔑 <code><?= htmlspecialchars($s['password']) ?></code></div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>