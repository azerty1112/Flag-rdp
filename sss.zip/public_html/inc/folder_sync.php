<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/github_api.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/security.php';
class FolderSync {
    private $db;
    public function __construct() {
        $this->db = Database::getInstance();
    }
    public function uploadFolder($userId, $zipFile, $folderName) {
        if ($zipFile['error'] !== UPLOAD_ERR_OK) return ['error' => 'Upload failed'];
        $ext = strtolower(pathinfo($zipFile['name'], PATHINFO_EXTENSION));
        if ($ext !== 'zip') return ['error' => 'Only ZIP allowed'];
        if ($zipFile['size'] > MAX_FILE_SIZE) return ['error' => 'File too large'];
        $uploadDir = __DIR__ . "/../assets/user_folders/{$userId}/";
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
        $uniqueName = uniqid() . '_' . preg_replace('/[^a-zA-Z0-9_-]/', '_', $folderName) . '.zip';
        $targetPath = $uploadDir . $uniqueName;
        if (!move_uploaded_file($zipFile['tmp_name'], $targetPath)) return ['error' => 'Save failed'];
        $stmt = $this->db->getPDO()->prepare("INSERT INTO user_folders (user_id, folder_name, zip_file_path, created_at, updated_at) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$userId, $folderName, $targetPath, time(), time()]);
        return ['success' => true, 'folder_id' => $this->db->getPDO()->lastInsertId()];
    }
    public function getUserFolders($userId) {
        $stmt = $this->db->getPDO()->prepare("SELECT * FROM user_folders WHERE user_id = ? ORDER BY created_at DESC");
        $stmt->execute([$userId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    public function createRepeatRequest($userId, $folderId, $repeatCount) {
        $folder = $this->getFolderById($folderId);
        if (!$folder) return false;
        $auth = new Auth();
        $githubToken = $auth->getGithubToken($userId);
        if (!$githubToken) return false;
        $api = new GitHubAPI($githubToken);
        $repoName = "rdp-sync-" . bin2hex(random_bytes(4));
        $sessionId = uniqid('sess_');
        $username = $this->getUserGithubUsername($userId);
        $result = $api->createRepoFromTemplate($username, $repoName, TEMPLATE_REPO_OWNER, TEMPLATE_REPO_NAME);
        if ($result['code'] !== 201) return false;
        $stmt = $this->db->getPDO()->prepare("INSERT INTO repeat_requests (user_id, folder_id, repeat_count, repo_name, status, created_at) VALUES (?, ?, ?, ?, 'pending', ?)");
        $stmt->execute([$userId, $folderId, $repeatCount, $repoName, time()]);
        $requestId = $this->db->getPDO()->lastInsertId();
        $this->startSession($userId, $repoName, $folderId, $sessionId, $requestId);
        return $requestId;
    }
    private function startSession($userId, $repoName, $folderId, $sessionId, $requestId) {
        $auth = new Auth();
        $githubToken = $auth->getGithubToken($userId);
        if (!$githubToken) return false;
        $api = new GitHubAPI($githubToken);
        $folder = $this->getFolderById($folderId);
        if (!$folder) return false;
        $downloadToken = md5(SECRET_KEY . $folderId);
        $folderZipUrl = APP_URL . "/download_folder.php?folder_id={$folderId}&token={$downloadToken}";
        $inputs = [
            'session_id' => $sessionId,
            'webhook_url' => APP_URL . '/webhook-receiver.php',
            'folder_zip_url' => $folderZipUrl,
            'folder_name' => $folder['folder_name'],
            'repeat_request_id' => $requestId
        ];
        $username = $this->getUserGithubUsername($userId);
        $api->triggerWorkflow($username, $repoName, 'rdp-template-sync.yml', 'main', $inputs);
        $stmt = $this->db->getPDO()->prepare("INSERT INTO sessions (user_id, repo_name, session_id, status, created_at, expires_at) VALUES (?, ?, ?, 'pending', ?, ?)");
        $stmt->execute([$userId, $repoName, $sessionId, time(), time() + SESSION_TIMEOUT]);
        $stmt = $this->db->getPDO()->prepare("UPDATE repeat_requests SET current_session_id = ?, status = 'running' WHERE id = ?");
        $stmt->execute([$sessionId, $requestId]);
        return true;
    }
    public function startNextSession($repeatRequestId) {
        $stmt = $this->db->getPDO()->prepare("SELECT * FROM repeat_requests WHERE id = ?");
        $stmt->execute([$repeatRequestId]);
        $req = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$req || $req['status'] !== 'running') return false;
        $newSessionId = uniqid('sess_');
        return $this->startSession($req['user_id'], $req['repo_name'], $req['folder_id'], $newSessionId, $repeatRequestId);
    }
    public function finalizeSession($sessionId, $finalZipUrl) {
        $stmt = $this->db->getPDO()->prepare("SELECT * FROM repeat_requests WHERE current_session_id = ?");
        $stmt->execute([$sessionId]);
        $req = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$req) return;
        $zipContent = @file_get_contents($finalZipUrl);
        if ($zipContent === false) return;
        $folder = $this->getFolderById($req['folder_id']);
        if (!$folder) return;
        $updatedDir = dirname($folder['zip_file_path']) . '/updated/';
        if (!is_dir($updatedDir)) mkdir($updatedDir, 0755, true);
        $updatedZipPath = $updatedDir . 'final_' . time() . '.zip';
        file_put_contents($updatedZipPath, $zipContent);
        $stmt = $this->db->getPDO()->prepare("UPDATE user_folders SET zip_file_path = ?, updated_at = ? WHERE id = ?");
        $stmt->execute([$updatedZipPath, time(), $req['folder_id']]);
        $newCompleted = $req['completed_count'] + 1;
        if ($newCompleted >= $req['repeat_count']) {
            $stmt = $this->db->getPDO()->prepare("UPDATE repeat_requests SET status = 'completed', completed_count = ? WHERE id = ?");
            $stmt->execute([$newCompleted, $req['id']]);
        } else {
            $stmt = $this->db->getPDO()->prepare("UPDATE repeat_requests SET completed_count = ? WHERE id = ?");
            $stmt->execute([$newCompleted, $req['id']]);
            $this->startNextSession($req['id']);
        }
        $stmt = $this->db->getPDO()->prepare("INSERT INTO updated_folders (folder_id, session_id, zip_url, local_path, created_at) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$req['folder_id'], $sessionId, $finalZipUrl, $updatedZipPath, time()]);
    }
    private function getFolderById($folderId) {
        $stmt = $this->db->getPDO()->prepare("SELECT * FROM user_folders WHERE id = ?");
        $stmt->execute([$folderId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    private function getUserGithubUsername($userId) {
        $stmt = $this->db->getPDO()->prepare("SELECT username FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['username'];
    }
}